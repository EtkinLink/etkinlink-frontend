"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { api } from "@/lib/api-client"
import Link from "next/link"
import {
  Calendar,
  MapPin,
  Users,
  Search,
  Filter,
  LogOut,
  Map,
  Plus,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"

interface Event {
  id: number
  title: string
  explanation: string
  starts_at: string
  ends_at: string | null
  location_name: string | null
  status: string
  event_type: string
  owner_username: string
  participant_count: number
  price: number
  latitude?: number
  longitude?: number
  distance_km?: number
}

function formatEventDate(iso: string) {
  // SSR ve client farkını önlemek için UTC timezone ile sabit format
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "UTC",
  }).format(new Date(iso))
}

export default function EventsPage() {
  const { user, logout, isLoading: authLoading } = useAuth()
  const router = useRouter()

  const [events, setEvents] = useState<Event[]>([])
  const [eventTypes, setEventTypes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState<string>("all")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [page, setPage] = useState(1)
  const [viewMode, setViewMode] = useState<"all" | "nearby">("all")
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [locationReady, setLocationReady] = useState(false)
  
  // ✅ ADIM 1: Hydration hatasını önlemek için "mounted" state'i
  const [isMounted, setIsMounted] = useState(false)

  // ✅ ADIM 2: Bileşenin sadece istemcide yüklendiğini belirt
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // --- Giriş kontrolü ---
  useEffect(() => {
    // ✅ Sadece istemcide (isMounted) ve auth yüklemesi bittikten sonra çalıştır
    if (isMounted && !authLoading && !user) {
      const token = localStorage.getItem("access_token") // Artık 'window' kontrolüne gerek yok
      if (!token) router.replace("/auth/login")
    }
  }, [isMounted, user, authLoading, router]) // ✅ isMounted'ı bağımlılıklara ekle

  // --- Etkinlik türlerini & konumu al ---
  useEffect(() => {
    // ✅ Sadece istemcide ve kullanıcı girişi yapıldıysa çalıştır
    if (!isMounted || !user) return

    fetchEventTypes()

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude })
          setLocationReady(true)
        },
        () => setLocationReady(true) // reddedilse bile state sabitlenmeli
      )
    } else {
      setLocationReady(true)
    }
  }, [isMounted, user]) // ✅ isMounted'ı bağımlılıklara ekle

  // --- Etkinlikleri al ---
  useEffect(() => {
    // ✅ Sadece istemcide ve kullanıcı girişi yapıldıysa çalıştır
    if (!isMounted || !user) return
    
    fetchEvents()
  }, [isMounted, page, selectedType, viewMode, userLocation]) // ✅ isMounted'ı bağımlılıklara ekle

  const fetchEventTypes = async () => {
    try {
      const types = await api.getEventTypes()
      setEventTypes(types)
    } catch (err) {
      console.error("Failed to fetch event types:", err)
    }
  }

  const fetchEvents = async () => {
    setIsLoading(true)
    try {
      const params: any = { page, page_size: 12, sort: "starts_at", order: "asc" }

      if (viewMode === "nearby" && userLocation) {
        const response = await api.getNearbyEvents(userLocation.lat, userLocation.lng, 10, params)
        setEvents(response.items || [])
      } else {
        const filterParams: any = { ...params }
        if (selectedType !== "all") filterParams.type = selectedType
        if (searchQuery) filterParams.q = searchQuery
        if (dateFrom) filterParams.from = dateFrom
        if (dateTo) filterParams.to = dateTo

        const response =
          selectedType !== "all" || searchQuery || dateFrom || dateTo
            ? await api.filterEvents(filterParams)
            : await api.getEvents(params)

        setEvents(response.items || [])
      }
    } catch (err) {
      console.error("Failed to fetch events:", err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setPage(1)
    fetchEvents()
  }

  const clearFilters = () => {
    setSearchQuery("")
    setSelectedType("all")
    setDateFrom("")
    setDateTo("")
    setPage(1)
  }

  const handleLogout = () => {
    logout()
    localStorage.removeItem("access_token")
    router.replace("/auth/login")
  }

  // ✅ ADIM 3: Sunucu ve istemcinin ilk render'da aynı şeyi görmesini sağla
  // Bileşen "mounted" olana KADAR veya auth yüklenene KADAR loader göster
  if (!isMounted || authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent" />
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  // ✅ Bu noktada isMounted = true ve authLoading = false
  // Artık !user kontrolünü güvenle yapabiliriz.
  if (!user) return null

  const hasActiveFilters = searchQuery || selectedType !== "all" || dateFrom || dateTo

  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="h-6 w-6 text-indigo-600" />
            <span className="text-xl font-bold">EtkinLink</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/events/create">
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Create Event
              </Button>
            </Link>
            <Link href="/profile">
              <Button variant="ghost" size="sm">Profile</Button>
            </Link>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" /> Sign out
            </Button>
          </nav>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 bg-muted/30">
        <div className="container py-8">
          <h1 className="mb-2 text-3xl font-bold">Discover Events</h1>
          <p className="text-muted-foreground mb-6">Find and join amazing campus events</p>

          {/* Tabs */}
          <Tabs
            value={viewMode}
            onValueChange={(v) => setViewMode(v as "all" | "nearby")}
            className="mb-6"
          >
            <TabsList>
              <TabsTrigger value="all">
                <Search className="mr-2 h-4 w-4" />
                All Events
              </TabsTrigger>

              <TabsTrigger value="nearby" disabled={!locationReady}>
                <Map className="mr-2 h-4 w-4" />
                Nearby Events {!userLocation && "(Enable location)"}
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Filters */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <form onSubmit={handleSearch} className="space-y-4">
                <div className="flex flex-col gap-4 sm:flex-row">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      className="pl-9"
                      placeholder="Search events..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>

                  <Select value={selectedType} onValueChange={(val) => setSelectedType(val)}>
                    <SelectTrigger className="w-full sm:w-[200px]">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {eventTypes.map((t) => (
                        <SelectItem key={t.id} value={t.code}>
                          {t.code}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex flex-col gap-4 sm:flex-row">
                  <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
                  <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
                  <Button type="submit">Apply</Button>
                  {hasActiveFilters && (
                    <Button type="button" variant="outline" onClick={clearFilters}>
                      Clear
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Events */}
          {isLoading ? (
            <p className="text-center text-muted-foreground">Loading events...</p>
          ) : events.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                No events found
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {events.map((ev) => (
                <Link key={ev.id} href={`/events/${ev.id}`}>
                  <Card className="h-full transition hover:shadow-md">
                    <CardHeader>
                      <div className="flex justify-between mb-2">
                        <Badge variant="secondary">{ev.event_type}</Badge>
                        {ev.price > 0 && <Badge variant="outline">${ev.price}</Badge>}
                      </div>
                      <CardTitle>{ev.title}</CardTitle>
                      <CardDescription>{ev.explanation}</CardDescription>
                    </CardHeader>
                    <CardContent className="text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        {formatEventDate(ev.starts_at)}
                      </div>
                      {ev.location_name && (
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4" />
                          {ev.location_name}
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        {ev.participant_count} participants
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}