"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { api } from "./api-client"

interface User {
  username: string
  name: string
  email: string
  attendance_rate: number
}

interface AuthContextType {
  user: User | null
  token: string | null
  login: (userId: number) => Promise<void>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for existing token on mount
    const storedToken = localStorage.getItem("auth_token")
    if (storedToken) {
      setToken(storedToken)
      fetchProfile()
    } else {
      setIsLoading(false)
    }
  }, [])

  const fetchProfile = async () => {
    try {
      const profile = await api.getProfile()
      setUser(profile)
    } catch (error) {
      console.error("Failed to fetch profile:", error)
      logout()
    } finally {
      setIsLoading(false)
    }
  }

  const login = async (userId: number) => {
    try {
      const response = await api.testLogin(userId)
      const newToken = response.access_token

      localStorage.setItem("auth_token", newToken)
      setToken(newToken)

      // Fetch user profile
      await fetchProfile()
    } catch (error) {
      console.error("Login failed:", error)
      throw error
    }
  }

  const logout = () => {
    localStorage.removeItem("auth_token")
    setToken(null)
    setUser(null)
  }

  return <AuthContext.Provider value={{ user, token, login, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
