"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { api } from "@/lib/api-client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Calendar, MapPin, Edit2, Save, X, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ParticipatedEvent {
  id: number
  title: string
  starts_at: string
  ends_at: string | null
  location_name: string | null
  status: string
  event_type: string
  participation_status: string
}

export default function ProfilePage() {
  const { user, isLoading: authLoading } = useAuth()
  const router = useRouter()
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [participatedEvents, setParticipatedEvents] = useState<ParticipatedEvent[]>([])
  const [universities, setUniversities] = useState<any[]>([])
  const [formData, setFormData] = useState({
    username: "",
    name: "",
    university_id: "",
  })

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/auth/login")
    } else if (user) {
      setFormData({
        username: user.username,
        name: user.name,
        university_id: "",
      })
      fetchParticipatedEvents()
      fetchUniversities()
    }
  }, [user, authLoading])

  const fetchParticipatedEvents = async () => {
    if (!user) return
    try {
      // Get current user's ID from profile
      const profile = await api.getProfile()
      // For now, we'll use username to match - in real app would use user ID
      const events = await api.getUserEvents(1) // Using test user ID
      setParticipatedEvents(events)
    } catch (error) {
      console.error("Failed to fetch participated events:", error)
    }
  }

  const fetchUniversities = async () => {
    try {
      const unis = await api.getUniversities()
      setUniversities(unis)
    } catch (error) {
      console.error("Failed to fetch universities:", error)
    }
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      const payload: any = {
        username: formData.username,
        name: formData.name,
      }
      if (formData.university_id) {
        payload.university_id = Number.parseInt(formData.university_id)
      }
      await api.updateProfile(payload)
      setIsEditing(false)
      // Refresh profile
      window.location.reload()
    } catch (error: any) {
      alert(error.message || "Failed to update profile")
    } finally {
      setIsSaving(false)
    }
  }

  if (authLoading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  const upcomingEvents = participatedEvents.filter((e) => new Date(e.starts_at) > new Date())
  const pastEvents = participatedEvents.filter((e) => new Date(e.starts_at) <= new Date())

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="container py-8">
        <Link href="/events">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Events
          </Button>
        </Link>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Profile</CardTitle>
                  {!isEditing ? (
                    <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                      <Edit2 className="mr-2 h-4 w-4" />
                      Edit
                    </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                        <X className="h-4 w-4" />
                      </Button>
                      <Button size="sm" onClick={handleSave} disabled={isSaving}>
                        <Save className="mr-2 h-4 w-4" />
                        {isSaving ? "Saving..." : "Save"}
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center">
                  <Avatar className="h-24 w-24">
                    <AvatarFallback className="text-2xl">{user.name[0].toUpperCase()}</AvatarFallback>
                  </Avatar>
                </div>

                {isEditing ? (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        value={formData.username}
                        onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="university">University</Label>
                      <Select
                        value={formData.university_id}
                        onValueChange={(value) => setFormData({ ...formData, university_id: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select university" />
                        </SelectTrigger>
                        <SelectContent>
                          {universities.map((uni) => (
                            <SelectItem key={uni.id} value={uni.id.toString()}>
                              {uni.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Username</p>
                      <p className="font-medium">{user.username}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Full Name</p>
                      <p className="font-medium">{user.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="font-medium">{user.email}</p>
                    </div>
                  </div>
                )}

                <Separator />

                <div>
                  <p className="mb-2 text-sm text-muted-foreground">Attendance Rate</p>
                  <div className="flex items-center gap-2">
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full bg-indigo-600"
                        style={{
                          width: `${user.attendance_rate === -1 ? 0 : user.attendance_rate}%`,
                        }}
                      />
                    </div>
                    <span className="text-sm font-medium">
                      {user.attendance_rate === -1 ? "N/A" : `${user.attendance_rate}%`}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 rounded-lg bg-muted p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold">{participatedEvents.length}</p>
                    <p className="text-sm text-muted-foreground">Events Joined</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold">{upcomingEvents.length}</p>
                    <p className="text-sm text-muted-foreground">Upcoming</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Events List */}
          <div className="space-y-6 lg:col-span-2">
            {/* Upcoming Events */}
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Events ({upcomingEvents.length})</CardTitle>
                <CardDescription>Events you're participating in</CardDescription>
              </CardHeader>
              <CardContent>
                {upcomingEvents.length === 0 ? (
                  <p className="text-center text-muted-foreground">No upcoming events</p>
                ) : (
                  <div className="space-y-4">
                    {upcomingEvents.map((event) => (
                      <Link key={event.id} href={`/events/${event.id}`}>
                        <Card className="transition-shadow hover:shadow-md">
                          <CardContent className="pt-6">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1">
                                <div className="mb-2 flex items-center gap-2">
                                  <Badge variant="secondary">{event.event_type}</Badge>
                                  <Badge variant="outline">{event.participation_status}</Badge>
                                </div>
                                <h3 className="mb-2 font-semibold">{event.title}</h3>
                                <div className="space-y-1 text-sm text-muted-foreground">
                                  <div className="flex items-center gap-2">
                                    <Calendar className="h-4 w-4" />
                                    <span>
                                      {new Date(event.starts_at).toLocaleDateString("en-US", {
                                        month: "short",
                                        day: "numeric",
                                        year: "numeric",
                                        hour: "2-digit",
                                        minute: "2-digit",
                                      })}
                                    </span>
                                  </div>
                                  {event.location_name && (
                                    <div className="flex items-center gap-2">
                                      <MapPin className="h-4 w-4" />
                                      <span>{event.location_name}</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Past Events */}
            <Card>
              <CardHeader>
                <CardTitle>Past Events ({pastEvents.length})</CardTitle>
                <CardDescription>Events you've attended</CardDescription>
              </CardHeader>
              <CardContent>
                {pastEvents.length === 0 ? (
                  <p className="text-center text-muted-foreground">No past events</p>
                ) : (
                  <div className="space-y-4">
                    {pastEvents.map((event) => (
                      <Link key={event.id} href={`/events/${event.id}`}>
                        <Card className="transition-shadow hover:shadow-md">
                          <CardContent className="pt-6">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1">
                                <div className="mb-2 flex items-center gap-2">
                                  <Badge variant="secondary">{event.event_type}</Badge>
                                  <Badge variant={event.participation_status === "ATTENDED" ? "default" : "outline"}>
                                    {event.participation_status}
                                  </Badge>
                                </div>
                                <h3 className="mb-2 font-semibold">{event.title}</h3>
                                <div className="space-y-1 text-sm text-muted-foreground">
                                  <div className="flex items-center gap-2">
                                    <Calendar className="h-4 w-4" />
                                    <span>
                                      {new Date(event.starts_at).toLocaleDateString("en-US", {
                                        month: "short",
                                        day: "numeric",
                                        year: "numeric",
                                      })}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
